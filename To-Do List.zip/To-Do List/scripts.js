// Get references to DOM elements
const taskInput = document.getElementById('taskInput');
const addTaskBtn = document.getElementById('addTaskBtn');
const taskList = document.getElementById('taskList');
const taskStats = document.getElementById('taskStats');
const mobileMenuBtn = document.getElementById('mobileMenuBtn');
const navLinks = document.querySelector('nav ul');

// Array to store tasks
let tasks = [];

// Load tasks from local storage when the page loads
document.addEventListener('DOMContentLoaded', () => {
    const storedTasks = JSON.parse(localStorage.getItem('tasks')) || [];
    tasks = storedTasks;
    renderTasks();
});

// Function to add a task
function addTask() {
    const taskName = taskInput.value.trim();

    if (taskName !== "") {
        const task = {
            id: Date.now(),
            name: taskName,
            completed: false
        };

        tasks.push(task);
        saveTasksToLocalStorage();  // Save tasks to local storage
        renderTasks();
        taskInput.value = ""; // Clear input field
    } else {
        alert("Please enter a task!");
    }
}

// Function to render tasks
function renderTasks() {
    // Clear existing tasks
    taskList.innerHTML = '';

    tasks.forEach(task => {
        // Create list item for each task
        const li = document.createElement('li');

        // Checkbox to mark task as completed
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.checked = task.completed;
        checkbox.addEventListener('change', () => toggleTaskCompletion(task.id));

        // Task name (span element)
        const taskName = document.createElement('span');
        taskName.textContent = task.name;
        if (task.completed) {
            taskName.classList.add('completed');
        }

        // Delete button
        const deleteBtn = document.createElement('button');
        deleteBtn.textContent = 'Delete';
        deleteBtn.classList.add('delete-btn');
        deleteBtn.addEventListener('click', () => deleteTask(task.id));

        // Append checkbox, task name, and delete button to the list item
        li.appendChild(checkbox);
        li.appendChild(taskName);
        li.appendChild(deleteBtn);

        // Append the list item to the task list
        taskList.appendChild(li);
    });

    // Update task stats
    updateTaskStats();
}

// Function to toggle task completion
function toggleTaskCompletion(taskId) {
    tasks = tasks.map(task => {
        if (task.id === taskId) {
            return { ...task, completed: !task.completed };
        }
        return task;
    });

    saveTasksToLocalStorage();  // Save updated tasks to local storage
    renderTasks();
}

// Function to delete a task
function deleteTask(taskId) {
    tasks = tasks.filter(task => task.id !== taskId);
    saveTasksToLocalStorage();  // Save updated tasks to local storage
    renderTasks();
}

// Function to update task stats
function updateTaskStats() {
    const totalTasks = tasks.length;
    const completedTasks = tasks.filter(task => task.completed).length;

    taskStats.textContent = `Total tasks: ${totalTasks} | Completed tasks: ${completedTasks}`;
}

// Save tasks to local storage
function saveTasksToLocalStorage() {
    localStorage.setItem('tasks', JSON.stringify(tasks));
}

// Event listener for the Add Task button
addTaskBtn.addEventListener('click', addTask);

// Event listener for pressing "Enter" key in the input field
taskInput.addEventListener('keyup', function(event) {
    if (event.key === 'Enter') {
        addTask();
    }
});

mobileMenuBtn.addEventListener('click', () => {
    navLinks.classList.toggle('active');
});
