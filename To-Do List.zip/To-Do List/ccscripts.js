const fromCurrency = document.getElementById('fromCurrency');
const toCurrency = document.getElementById('toCurrency');
const amountInput = document.getElementById('amountInput');
const convertBtn = document.getElementById('convertBtn');
const conversionResult = document.getElementById('conversionResult');
const mobileMenuBtn = document.getElementById('mobileMenuBtn');
const navLinks = document.querySelector('nav ul');

let currencyData = {}; // Object to hold currency rates

// Fetch currency data from API
async function fetchCurrencyData() {
    const apiKey = '6b39c2f9126df8b5f3dcc6e9'; // Replace with your API key
    const url = `https://v6.exchangerate-api.com/v6/${apiKey}/latest/USD`; // Fetch rates relative to USD

    try {
        const response = await fetch(url);
        const data = await response.json();

        if (data && data.conversion_rates) {
            currencyData = data.conversion_rates; // Store the fetched rates
            populateCurrencySelects();
        }
    } catch (error) {
        console.error('Error fetching currency data:', error);
    }
}

// Populate currency dropdowns
function populateCurrencySelects() {
    const currencyCodes = Object.keys(currencyData);
    
    currencyCodes.forEach(currency => {
        const option1 = document.createElement('option');
        option1.value = currency;
        option1.textContent = currency;
        fromCurrency.appendChild(option1);

        const option2 = document.createElement('option');
        option2.value = currency;
        option2.textContent = currency;
        toCurrency.appendChild(option2);
    });

    fromCurrency.value = 'USD'; // Default from currency
    toCurrency.value = 'EUR'; // Default to currency
}

// Convert currency
convertBtn.addEventListener('click', () => {
    const amount = parseFloat(amountInput.value);
    const fromRate = currencyData[fromCurrency.value];
    const toRate = currencyData[toCurrency.value];

    if (isNaN(amount) || amount <= 0) {
        conversionResult.textContent = 'Please enter a valid amount.';
        return;
    }

    const convertedAmount = (amount / fromRate) * toRate;
    conversionResult.textContent = `${amount} ${fromCurrency.value} = ${convertedAmount.toFixed(2)} ${toCurrency.value}`;
});

// Initialize the currency converter by fetching data
fetchCurrencyData();

mobileMenuBtn.addEventListener('click', () => {
    navLinks.classList.toggle('active');
});
